from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import tarfile
import time

root = Path('/tmp/subathon-session-sdk')
repo = Path('/home/archnoob/ProgrammingProjects/SubathonProject/subathon-bot-ai')
archive = root / 'libsodium-1.0.22.tar.gz'
expected_hash = 'adbdd8f16149e81ac6078a03aca6fc03b592b89ef7b5ed83841c086191be3349'
expected_size = 2008529
receipt_path = root / 'sdk-preparation.json'

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def artifact(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

receipt = {
    'scope': 'SESSIONTEST-008 bounded dependency SDK preparation only; no foundation, feature, vendor test or runtime smoke execution',
    'started_utc': utc(),
    'source_url': 'https://download.libsodium.org/libsodium/releases/libsodium-1.0.22.tar.gz',
    'download_attempts': [
        {'sandbox': 'default', 'exit_code': 6, 'http_code': 0, 'bytes_downloaded': 0, 'stderr': 'download.stderr.log'},
        {'sandbox': 'authorized network escalation', 'exit_code': 0, 'http_code': 200, 'bytes_downloaded': 2008529, 'stderr': 'download-network.stderr.log', 'headers': 'download-network.headers'},
    ],
    'admission_evidence': [
        'docs/evidence/sessiontest-001-dependency-preparation.md',
        'docs/evidence/sessiontest-001-source-authentication.json',
        'docs/evidence/sessiontest-001-minimal-review.md',
        'docs/evidence/sessiontest-001-environment-review.md',
    ],
    'phases': [],
}

def save():
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')

try:
    before = artifact(archive)
    if before['bytes'] != expected_size or before['sha256'] != expected_hash:
        raise RuntimeError('Archive exact byte count/hash mismatch; extraction and configure prohibited')
    receipt['verified_archive_before_extraction'] = {'verified_utc': utc(), **before}
    save()
    (root / 'archive-verification.json').write_text(json.dumps(receipt['verified_archive_before_extraction'], indent=2) + '\n')

    tracked_paths = [
        'AGENTS.md', '.github/workflows/password-hashing.yml', 'cmake/SodiumDependency.cmake',
        'docs/evidence/sessiontest-001-dependency-preparation.md',
        'docs/evidence/sessiontest-001-source-authentication.json',
        'docs/evidence/sessiontest-001-sdk-build.json',
        'docs/evidence/sessiontest-001-minimal-review.md',
        'docs/evidence/sessiontest-001-environment-review.md',
        'server/include/subathon/server/password_hashing.hpp', 'server/src/password_hashing.cpp',
    ]
    repo_before = {path: artifact(repo / path) for path in tracked_paths}
    (root / 'repository-inputs-before.json').write_text(json.dumps(repo_before, indent=2) + '\n')

    env_commands = [
        ['uname', '-a'], ['gcc', '--version'], ['make', '--version'],
        ['/usr/bin/bash', '--version'], ['getconf', 'GNU_LIBC_VERSION'],
        ['python3', '--version'], ['ld', '--version'], ['ar', '--version'],
    ]
    env_records = []
    with (root / 'environment.log').open('w') as log:
        for argv in env_commands:
            result = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
            record = {'argv': argv, 'exit_code': result.returncode, 'stdout': result.stdout}
            env_records.append(record)
            log.write('$ ' + shlex.join(argv) + '\n' + result.stdout + '\n')
    receipt['environment'] = {
        'system': platform.system(), 'machine': platform.machine(),
        'tool_queries': env_records,
        'inherited_build_environment': {name: os.environ.get(name) for name in ['CC', 'CXX', 'CFLAGS', 'CPPFLAGS', 'CXXFLAGS', 'LDFLAGS', 'LIBS', 'MAKEFLAGS', 'CONFIG_SITE', 'LD_PRELOAD', 'LD_LIBRARY_PATH']},
        'configure_overrides': {'CC': 'gcc', 'CFLAGS': '-O2'},
    }

    source_container = root / 'source'
    build = root / 'build'
    prefix = root / 'prefix'
    for path in [source_container, build, prefix]:
        if path.exists():
            raise RuntimeError(f'Fresh isolated directory required: {path}')
    source_container.mkdir()
    build.mkdir()
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        if any(not (member.isdir() or member.isfile()) for member in members):
            raise RuntimeError('Unexpected nonregular archive entry')
        if any(Path(member.name).is_absolute() or '..' in Path(member.name).parts or Path(member.name).parts[0] != 'libsodium-1.0.22' for member in members):
            raise RuntimeError('Unexpected archive path')
        regulars = [member for member in members if member.isfile()]
        source_manifest = {member.name: {'bytes': member.size, 'sha256': hashlib.sha256(tar.extractfile(member).read()).hexdigest()} for member in regulars}
        if len(source_manifest) != len(regulars):
            raise RuntimeError('Duplicate archive source file')
        receipt['archive_entries'] = len(members)
        receipt['archive_regular_bytes'] = sum(member.size for member in regulars)
        receipt['archive_regular_files'] = len(regulars)
        receipt['archive_links'] = 0
        receipt['extraction_started_utc'] = utc()
        tar.extractall(source_container, filter='data')
    (root / 'vendor-files-before.json').write_text(json.dumps(source_manifest, indent=2) + '\n')
    for name, expected in source_manifest.items():
        if artifact(source_container / name)['sha256'] != expected['sha256']:
            raise RuntimeError(f'Extracted source differs: {name}')
    receipt['extracted_source_matches_archive_before_configure'] = True
    save()

    def phase(name, command):
        stdout_path = root / (name + '.stdout.log')
        stderr_path = root / (name + '.stderr.log')
        limit_path = root / (name + '.core-limit')
        shell = 'ulimit -c 0\nulimit -c > ' + shlex.quote(str(limit_path)) + '\nexec ' + shlex.join(command)
        argv = ['/usr/bin/bash', '-c', shell]
        record = {'name': name, 'cwd': str(build), 'argv': argv, 'started_utc': utc(), 'stdout_log': str(stdout_path), 'stderr_log': str(stderr_path)}
        receipt['phases'].append(record)
        save()
        start = time.monotonic()
        with stdout_path.open('wb') as out, stderr_path.open('wb') as err:
            result = subprocess.run(argv, cwd=build, stdout=out, stderr=err, check=False)
        record.update({'exit_code': result.returncode, 'elapsed_seconds': round(time.monotonic() - start, 6), 'finished_utc': utc(), 'child_core_limit': limit_path.read_text().strip(), 'stdout': artifact(stdout_path), 'stderr': artifact(stderr_path)})
        save()
        print(name + ': exit ' + str(result.returncode) + ', core limit ' + record['child_core_limit'], flush=True)
        if result.returncode != 0:
            raise RuntimeError('SDK phase failed: ' + name)

    source = source_container / 'libsodium-1.0.22'
    phase('configure', ['env', 'CC=gcc', 'CFLAGS=-O2', '/usr/bin/bash', str(source / 'configure'), '--prefix=' + str(prefix), '--libdir=' + str(prefix / 'lib'), '--disable-shared', '--enable-static'])
    phase('build', ['make', '-j2'])
    phase('install', ['make', '-j2', 'install'])

    source_after = {}
    for path in source.rglob('*'):
        if path.is_file():
            source_after[str(path.relative_to(source_container))] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    (root / 'vendor-files-after.json').write_text(json.dumps(source_after, indent=2) + '\n')
    if source_after != source_manifest:
        raise RuntimeError('Vendor source preservation check failed')
    receipt['vendor_files_unchanged'] = len(source_after)
    receipt['source_manifest_before'] = artifact(root / 'vendor-files-before.json')
    receipt['source_manifest_after'] = artifact(root / 'vendor-files-after.json')
    receipt['archive_unchanged_after_build'] = artifact(archive) == before

    repo_after = {path: artifact(repo / path) for path in tracked_paths}
    (root / 'repository-inputs-after.json').write_text(json.dumps(repo_after, indent=2) + '\n')
    receipt['repository_inputs_unchanged'] = repo_before == repo_after
    receipt['repository_input_changes'] = [path for path in tracked_paths if repo_before[path] != repo_after[path]]
    headers = sorted((prefix / 'include').rglob('*.h'))
    receipt['installed_headers'] = [artifact(path) for path in headers]
    receipt['sdk_artifacts'] = [artifact(prefix / 'lib/libsodium.a'), artifact(prefix / 'include/sodium.h'), artifact(prefix / 'include/sodium/version.h'), artifact(prefix / 'lib/pkgconfig/libsodium.pc')]
    receipt['header_version_declarations'] = [line for line in (prefix / 'include/sodium/version.h').read_text().splitlines() if line.startswith('#define SODIUM_VERSION_STRING ') or line.startswith('#define SODIUM_LIBRARY_VERSION_')]
    receipt['prefix'] = str(prefix)
    receipt['config_log'] = artifact(build / 'config.log')
    receipt['no_vendor_tests_foundation_feature_or_runtime_smoke_executed'] = True
    receipt['runtime_identity_verified'] = False
    receipt['external_crash_handler_retention'] = 'not inspected; child core limits recorded as 0'
    receipt['finished_utc'] = utc()
    receipt['status'] = 'prepared; root admission and separate actual foundation review remain'
    save()
    print(json.dumps({key: receipt[key] for key in ['status', 'prefix', 'vendor_files_unchanged', 'repository_inputs_unchanged', 'header_version_declarations', 'sdk_artifacts']}, indent=2), flush=True)
except BaseException as exc:
    receipt['failure'] = str(exc)
    receipt['failure_utc'] = utc()
    save()
    raise
